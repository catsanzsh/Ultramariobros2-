make us   # Build the US version
make jp   # Build the Japanese version
make eu   # Build the EU version

make EMULATOR=project64   # Build and launch for Project64
make EMULATOR=parallel    # Build and launch for Parallel Launcher
make EMULATOR=retroarch   # Build and launch for RetroArch
make EMULATOR=mupen64     # Build and launch for Mupen64
