#ifdef VERSION_JP
// JP region-specific code or data
#define MARIO_START_POS 0x803B0000
#elif defined(VERSION_US)
// US region-specific code or data
#define MARIO_START_POS 0x803C0000
#elif defined(VERSION_EU)
// EU region-specific code or data
#define MARIO_START_POS 0x803D0000
#endif
